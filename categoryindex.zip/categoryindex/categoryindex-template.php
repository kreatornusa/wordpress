<?php
/*
Template Name: Page Template for AZ Categories Index
Author URI: http://www.kreatornusa.com
*/
?> 
<?php get_header(); ?>

<?php get_template_part('inc/judul3'); ?>
<div id="content" class="widecolumn">
<?php 

//get the page letter, account for permalink changes
$az_url_query = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
if($az_url_query){
	$pageletter = get_page_uri(str_replace("page_id=", "", $az_url_query));
} else {
	$pageletter = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
}

//get site url
$az_cat_start = get_site_url();

//get permalink_structure
$az_permalink_query = $wpdb->get_var( $wpdb->prepare("SELECT option_value FROM  wp_options WHERE option_name = 'permalink_structure'"));


if($az_permalink_query){
	$az_cat_query = $wpdb->get_var( $wpdb->prepare("SELECT option_value FROM  wp_options WHERE option_name = 'category_base'"));
	if($az_cat_query){
		//if permalink is specified and category_base is also set, categories just use teh category_base word
		$az_cat_start .= $az_cat_query.'/';
	} else {
		//if permalink is not default and category_base is not specified, categories use any non-tag word or words before the tag plus the word category
		$az_cat_prefix = current(explode("%", $az_permalink_query));
		$az_cat_start .= $az_cat_prefix.'category/';
	}
}

if($pageletter == "0-9"){
	$myrows = $wpdb->get_results($wpdb->prepare("SELECT name, term_id FROM wp_categoryindex WHERE alpha IN ('0','1','2','3','4','5','6','7','8','9')")); 
} else {
	$myrows = $wpdb->get_results($wpdb->prepare("SELECT name, term_id FROM wp_categoryindex WHERE alpha = '$pageletter'")); 
}


echo '<div class="aaa">';
if($myrows){
	$pretag = '<div class="post"><h2>';
	$posttag = '</h2></div>';

	foreach($myrows as $row){ 
		$categoryname = $row->name;
		if($az_permalink_query){
			$categoryurl = $pretag.'<a href="'.$az_cat_start.strtolower(str_replace(" ", "-", $categoryname)).'">+ '.$categoryname.'</a>'.$posttag;
		} else {
			//if we have default permalinks, wordpress will always use ?cat=ID
			$categoryurl = $pretag.'<a href="'.$az_cat_start.'/?cat='.$row->term_id.'">'.$categoryname.'</a>'.$posttag;
		}
		echo $categoryurl;
	} 

} else {
	echo '<div id="az-noresults">No Results</span>';
}
echo  '</div>';


?>
</div>
<div id="main">
</div>
<?php get_footer(); ?>