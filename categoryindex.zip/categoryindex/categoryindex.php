<?php
/**
 * @package A-Z Category Index
 * @version 0.1
 */
/*
Plugin Name: DewaGitar - A-Z Category
Plugin URI: http://wordpress.org/
Description: Indeks Kategori A-Z di mana setiap huruf membawa Anda ke halaman dengan daftar kategori yang dimulai dengan huruf itu.
Version: 0.1
Author URI: http://www.kreatornusa.com
*/

register_activation_hook(__FILE__,'azindexx_install');
register_deactivation_hook(__FILE__, 'azindexx_uninstall' );

global $jal_db_version;
$jal_db_version = "1.0";

function azindexx_install() {
  global $wpdb;
  global $jal_db_version;

  $table_name = $wpdb->prefix . "categoryindex";

  //this call will put 2pac under 2, but not sure if you should change it as SUBSTR is kinda cool and only change is 0-9 page making 10 requests...
  $sql = "CREATE TABLE $table_name AS SELECT SUBSTR(name,1,1) AS alpha, term_id, name FROM wp_terms WHERE term_id IN (SELECT term_taxonomy_id FROM wp_term_taxonomy WHERE taxonomy =  'category')";

  require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
  dbDelta($sql);

  foreach (range('A', 'Z') as $letter) {
    $my_page_a = array(
    'post_title' => $letter,
    'post_status' => 'publish',
    'post_type' => 'page'
    );
    wp_insert_post($my_page_a);
  }

  //add the 0-9 page
  $my_page_a = array(
    'post_title' => '0-9',
    'post_status' => 'publish',
    'post_type' => 'page'
  );
  wp_insert_post($my_page_a);

  add_option("jal_db_version", $jal_db_version);

}

function azindexx_uninstall() {
  global $wpdb;
  global $jal_db_version;

  $table_name = $wpdb->prefix . "categoryindex";

  $wpdb->query("DROP TABLE IF EXISTS $table_name");

  require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
  dbDelta($sql);

  //deletes all pages
  $sql = "DELETE a,b,c FROM wp_posts a LEFT JOIN wp_term_relationships b ON (a.ID = b.object_id) LEFT JOIN wp_postmeta c ON (a.ID = c.post_id) WHERE a.post_title IN ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0-9')";
  $wpdb->query($sql);
}


add_action('create_category', 'tcreate_category');
add_action('edited_category', 'tedit_category');
add_action('delete_category', 'tdelete_category');


function tcreate_category($cat_ID){
  global $wpdb;
  $table_name = $wpdb->prefix . "categoryindex";

  $category = get_the_category_by_ID($cat_ID);
  $alpha = strtoupper($category[0]);
  $wpdb->insert( $table_name, array( 'alpha' => $alpha, 'term_id' => $cat_ID, 'name' => $category ) );
}

function tedit_category($cat_ID){
  global $wpdb;
  $table_name = $wpdb->prefix . "categoryindex";

  $category = get_the_category_by_ID($cat_ID);
  $alpha = strtoupper($category[0]);
  $wpdb->update( $table_name, array( 'alpha' => $alpha, 'name' => $category ), array( 'term_id' => $cat_ID ) );
}

function tdelete_category($cat_ID){
  global $wpdb;
  $table_name = $wpdb->prefix . "categoryindex";

  $sql = "DELETE FROM $table_name WHERE term_id = $cat_ID";
  $wpdb->query($sql);
}

function add_cat_index() {
    $html = '<div id="az-categoryindex">
    <span><a href="'.esc_url( get_permalink( get_page_by_title("0-9")) ).'">0-9</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("A")) ).'">A</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("B")) ).'">B</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("C")) ).'">C</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("D")) ).'">D</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("E")) ).'">E</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("F")) ).'">F</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("G")) ).'">G</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("H")) ).'">H</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("I")) ).'">I</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("J")) ).'">J</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("K")) ).'">K</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("L")) ).'">L</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("M")) ).'">M</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("N")) ).'">N</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("O")) ).'">O</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("P")) ).'">P</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("Q")) ).'">Q</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("R")) ).'">R</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("S")) ).'">S</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("T")) ).'">T</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("U")) ).'">U</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("V")) ).'">V</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("W")) ).'">W</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("X")) ).'">X</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("Y")) ).'">Y</a></span>
<span><a href="'.esc_url( get_permalink( get_page_by_title("Z")) ).'">Z</a></span>
</div>';
    return $html;
}

add_filter( 'page_template', 'catindex_page_template' );
function catindex_page_template( $page_template )
{
    //http://codex.wordpress.org/Function_Reference/is_page
    if ( is_page(array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0-9','test')) ) {
        $page_template = dirname( __FILE__ ) . '/categoryindex-template.php';
    }
    return $page_template;
}

?>